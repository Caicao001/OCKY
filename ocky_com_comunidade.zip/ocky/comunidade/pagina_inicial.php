<?php session_start(); ?>
<?php include("login_verificar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        echo "Olá, " . $_SESSION["username"];
    ?>



    <h1>Perguntas</h1>


    <a href="criar_pergunta_form.php">Criar Pergunta</a>

    <?php
          include("banco_dados_conexao.php");
          try {
            $sth = $dbh->prepare('SELECT * from post');
            $sth->execute();
            $result = $sth->fetchAll(PDO::FETCH_ASSOC);
            if(!empty($result)) {
                echo "<table>";
                echo "<tr>";
                echo "<th>Id</th>";
                echo "<th>Pergunta</th>";
                echo "<th>Data</th>";
                echo "</tr>";
                foreach($result as $row) {
                    echo "<tr>";
                    echo "<td>". $row["id"] ."</td>";
                    echo "<td><a href='pergunta.php?id=". $row["id"] ."'>".$row["pergunta"]."</a></td>";
                    echo "<td>". $row["data"] ."</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } 
            $dbh = null;
          } catch (PDOException $e) {
            print "Error!: " . $e->getMessage();
            die();
          }
        ?>










    <br><br><br><br>
    <a href="sair.php">Sair</a>
    
</body>
</html>