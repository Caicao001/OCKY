<?php session_start(); ?>
<?php include("login_verificar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        echo "Olá, " . $_SESSION["username"];
    ?>



    <h1>Perguntas</h1>


    <a href="criar_resposta_form.php">Criar Resposta</a>

    <br><br>

    <?php
          include("banco_dados_conexao.php");
          try {
            $_SESSION["id_post"] = $_GET["id"];
            $sth = $dbh->prepare('SELECT * from post WHERE id = ?');
            $sth->bindParam(1, $_GET["id"]);
            $sth->execute();
            $result = $sth->fetchAll(PDO::FETCH_ASSOC);
            if(!empty($result)) {
                echo $result[0]["data"];
                echo "<br>";
                echo $result[0]["pergunta"];
            } 
            
          } catch (PDOException $e) {
            print "Error!: " . $e->getMessage();
            die();
          }
        ?>

<?php
          
          try {
            $sth = $dbh->prepare('SELECT * from comentario where id_post=?');
            $sth->bindParam(1, $_GET["id"]);
            $sth->execute();
            $result = $sth->fetchAll(PDO::FETCH_ASSOC);
            if(!empty($result)) {
                echo "<table>";
                echo "<tr>";
                echo "<th>Id</th>";
                echo "<th>Resposta</th>";
                echo "<th>Data</th>";
                echo "</tr>";
                foreach($result as $row) {
                    echo "<tr>";
                    echo "<td>". $row["id"] ."</td>";
                    echo "<td>".$row["texto"]."</td>";
                    echo "<td>". $row["data"] ."</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } 
          } catch (PDOException $e) {
            print "Error!: " . $e->getMessage();
            die();
          }
        ?>







   






<?php $dbh = null; ?>
    <br><br><br><br>
    <a href="pagina_inicial.php">Voltar</a>
    
</body>
</html>