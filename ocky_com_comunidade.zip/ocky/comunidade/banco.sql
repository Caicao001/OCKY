CREATE DATABASE ocky;
USE ocky;


CREATE TABLE usuario(
    username VARCHAR(30) PRIMARY KEY
    ,senha VARCHAR(300)
);

CREATE TABLE post(
    id INTEGER AUTO_INCREMENT PRIMARY KEY
    , pergunta VARCHAR(300)
    , username VARCHAR(30) 
    , data DATE DEFAULT (CURRENT_DATE)
    , FOREIGN KEY (username) REFERENCES usuario(username)
);

CREATE TABLE comentario(
    id INTEGER AUTO_INCREMENT PRIMARY KEY
    , texto VARCHAR(300)
    , username VARCHAR(30) 
    , id_post INTEGER
    , data DATE DEFAULT (CURRENT_DATE)
    , FOREIGN KEY (username) REFERENCES usuario(username)
    , FOREIGN KEY (id_post) REFERENCES post(id)
);