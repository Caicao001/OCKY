<?php
session_start();
	
	include("banco_dados_conexao.php");

	try {

		
		$stmt = $dbh->prepare("select * from usuario where username=? and senha=?");
        $stmt->bindParam(1, $_POST["username"]);
        $stmt->bindParam(2, $_POST["senha"]);
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if(!empty($result)){
            $_SESSION["username"] = $result[0]["username"];
            header("Location: pagina_inicial.php");
        } else {
            echo "Erro no login!";
        }

		$dbh = null;
	} catch (PDOException $e) {
		print "Error!: " . $e->getMessage() . "<br/><br><a href='index.php'>voltar</a>";
		die();
	}

	?>